package com.ncv.testWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
